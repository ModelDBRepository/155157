
# to be called with 
#    cell_type = 'readout'
#    cell_type = 'pyr'
#    cell_type = 'mit'
# in the script
python plotting_and_analysis/plot_pattern_completion.py 1
